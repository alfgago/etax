CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('1', 'elikirk', '$P$BPw8I1GFpSARdrmTvM5ecLYg9l2hPG.', 'elikirk', 'rob@elikirk.com', '', '2015-10-09 15:02:34', '', '0', 'elikirk'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('3', 'carla', '$P$B9paMBLIaes.KDFqBh/1qys1/m/JTj1', 'carla', 'carla.pruitt@big-d.com', '', '2016-04-07 03:42:41', '', '0', 'Carla Pruitt'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('5', 'it', '$P$BjTcCBX3S8O/s2zo0BqWgNvQXb5oNQ0', 'it', 'it@big-d.com', '', '2017-06-08 22:06:23', '', '0', 'Big-D IT'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('7', 'AlanB', '$P$Bg9CMnom0/zpm4JUVtDe32H/aJz/B01', 'alanb', 'alan@stotion.com', '', '2017-06-16 19:29:08', '1497641348:$P$B57oLbNM/0Mf/d486iMqoOTqI8WZuy/', '0', 'Alan Bellows'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('8', 'SethT', '$P$Bo2CwS7ND5/0Q56RhtyRny1f4dMtRe1', 'setht', 'seth@stotion.com', '', '2017-06-16 19:32:40', '1497641560:$P$BJf2WhERXpdnqMun93Q2GEYMb1s46n1', '0', 'Seth Taylor'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('9', 'Exporter', '$P$BOPxsUCEYfHzpwaariuZU6s8sw2Kfl.', 'exporter', 'alan+exporter@stotion.com', '', '2019-05-13 17:01:39', '', '0', 'Exporter'); 
INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES ('10', 'stephanie.epstein', '$P$BXTOhziGICHt5UcgoiG7bEKbowOd9W.', 'stephanie-epstein', 'stephanie.epstein@big-d.com', 'http://big-d.com', '2019-12-06 20:17:04', '1575663424:$P$BT6QA75q1QXsUWXJoe7EoS6N3Srj7g0', '0', 'Stephanie Epstein');
# --------------------------------------------------------

