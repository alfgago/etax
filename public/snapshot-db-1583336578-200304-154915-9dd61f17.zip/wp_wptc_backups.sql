CREATE TABLE IF NOT EXISTS `wp_wptc_backups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `backup_id` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `backup_name` text COLLATE utf8mb4_unicode_520_ci,
  `backup_type` char(1) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'M = Manual, D = Daily Main Cycle , S- Sub Cycle',
  `files_count` int(11) NOT NULL,
  `memory_usage` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `update_details` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
TRUNCATE TABLE `wp_wptc_backups`;
 
INSERT INTO `wp_wptc_backups` (`id`, `backup_id`, `backup_name`, `backup_type`, `files_count`, `memory_usage`, `update_details`) VALUES ('1', '1573765893', 'Updated on 2:11 pm', 'M', '1620', '4.25', NULL); 
INSERT INTO `wp_wptc_backups` (`id`, `backup_id`, `backup_name`, `backup_type`, `files_count`, `memory_usage`, `update_details`) VALUES ('3', '1573778391', 'BK Dev', '', '0', '', NULL);
# --------------------------------------------------------

