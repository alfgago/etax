CREATE TABLE IF NOT EXISTS `wp_wptc_processed_iterator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `offset` text COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
TRUNCATE TABLE `wp_wptc_processed_iterator`;
 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('1', 'wp_cf7dbplugin_st', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('2', 'wp_cf7dbplugin_submits', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('3', 'wp_commentmeta', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('4', 'wp_comments', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('5', 'wp_links', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('6', 'wp_options', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('7', 'wp_podsrel', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('8', 'wp_postmeta', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('9', 'wp_posts', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('10', 'wp_redirection_404', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('11', 'wp_redirection_groups', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('12', 'wp_redirection_items', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('13', 'wp_redirection_logs', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('14', 'wp_term_relationships', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('15', 'wp_term_taxonomy', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('16', 'wp_termmeta', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('17', 'wp_terms', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('18', 'wp_usermeta', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('19', 'wp_users', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('20', 'wp_wfblockediplog', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('21', 'wp_wfblocks7', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('22', 'wp_wfconfig', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('23', 'wp_wfcrawlers', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('24', 'wp_wffilechanges', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('25', 'wp_wffilemods', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('26', 'wp_wfhits', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('27', 'wp_wfhoover', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('28', 'wp_wfissues', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('29', 'wp_wfknownfilelist', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('30', 'wp_wflivetraffichuman', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('31', 'wp_wflocs', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('32', 'wp_wflogins', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('33', 'wp_wfls_2fa_secrets', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('34', 'wp_wfls_settings', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('35', 'wp_wfnotifications', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('36', 'wp_wfpendingissues', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('37', 'wp_wfreversecache', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('38', 'wp_wfsnipcache', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('39', 'wp_wfstatus', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('40', 'wp_wftrafficrates', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('41', 'wp_yoast_seo_links', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('42', 'wp_yoast_seo_meta', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('43', '/domains', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('44', '/static', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('45', '/wp-admin', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('46', '/wp-includes', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('47', '/wp-content/mu-plugins', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('48', '/wp-content/plugins', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('49', '/wp-content/themes', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('50', '/wp-content/upgrade', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('51', '/wp-content/uploads', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('52', '/wp-content/wflogs', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('53', '/wp-content/ai1wm-backups', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('54', '/', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('55', '/wp-content', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('56', '/wp-content/tCapsule', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('57', '/uploads', '-1'); 
INSERT INTO `wp_wptc_processed_iterator` (`id`, `name`, `offset`) VALUES ('58', '/uploads/tCapsule', '-1');
# --------------------------------------------------------

