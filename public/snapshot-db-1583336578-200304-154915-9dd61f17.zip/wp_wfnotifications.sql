CREATE TABLE IF NOT EXISTS `wp_wfnotifications` (
  `id` varchar(32) NOT NULL DEFAULT '',
  `new` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `category` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '1000',
  `ctime` int(10) unsigned NOT NULL,
  `html` text NOT NULL,
  `links` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_wfnotifications`;
 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-24AAAAA', '0', 'wfplugin_updates', '502', '1562777091', '<a href="http://bigdsignature.stotion.work/wp-admin/update-core.php">An update is available for 1 plugin</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AEAAAAA', '0', 'wfplugin_updates', '502', '1558104470', '<a href="http://bigdsignature.stotion.work/wp-admin/update-core.php">An update is available for WordPress (v5.2)</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AIAAAAA', '0', 'wfplugin_scan', '502', '1564505113', '<a href="https://bigdsignature.stotion.work/wp-admin/admin.php?page=WordfenceScan">29 issues found in most recent scan</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AMAAAAA', '0', 'wfplugin_scan', '502', '1566100632', '<a href="https://bigdsignature.stotion.work/wp-admin/admin.php?page=WordfenceScan">3 issues found in most recent scan</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-AUAAAAA', '0', 'wfplugin_updates', '502', '1565199917', '<a href="https://bigdsignature.stotion.work/wp-admin/update-core.php">Updates are available for 3 plugins</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-DYAAAAA', '1', 'wfplugin_updates', '502', '1566837068', '<a href="https://bigdsignature.stotion.work/wp-admin/update-core.php">Updates are available for 2 plugins</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-EIAAAAA', '0', 'wfplugin_scan', '502', '1566398222', '<a href="https://bigdsignature.stotion.work/wp-admin/admin.php?page=WordfenceScan">5 issues found in most recent scan</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-FEAAAAA', '0', 'wfplugin_scan', '502', '1566601960', '<a href="https://bigdsignature.stotion.work/wp-admin/admin.php?page=WordfenceScan">8 issues found in most recent scan</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-FYAAAAA', '1', 'wfplugin_scan', '502', '1566837068', '<a href="https://bigdsignature.stotion.work/wp-admin/admin.php?page=WordfenceScan">4 issues found in most recent scan</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-HAAQAAA', '0', 'wfplugin_updates', '502', '1564505111', '<a href="http://bigdsignature.stotion.work/wp-admin/update-core.php">Updates are available for 5 plugins</a>', '[]'); 
INSERT INTO `wp_wfnotifications` (`id`, `new`, `category`, `priority`, `ctime`, `html`, `links`) VALUES ('site-RMAAAAA', '0', 'wfplugin_updates', '502', '1560356414', '<a href="http://bigdsignature.stotion.work/wp-admin/update-core.php">An update is available for 1 plugin</a>', '[]');
# --------------------------------------------------------

