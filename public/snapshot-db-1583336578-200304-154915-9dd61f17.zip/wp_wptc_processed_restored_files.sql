CREATE TABLE IF NOT EXISTS `wp_wptc_processed_restored_files` (
  `file` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `offset` int(50) DEFAULT '0',
  `uploadid` text COLLATE utf8mb4_unicode_520_ci,
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `backupID` double DEFAULT NULL,
  `revision_number` text COLLATE utf8mb4_unicode_520_ci,
  `revision_id` text COLLATE utf8mb4_unicode_520_ci,
  `mtime_during_upload` varchar(22) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `download_status` text COLLATE utf8mb4_unicode_520_ci,
  `uploaded_file_size` text COLLATE utf8mb4_unicode_520_ci,
  `process_type` text COLLATE utf8mb4_unicode_520_ci,
  `copy_status` text COLLATE utf8mb4_unicode_520_ci,
  `g_file_id` text COLLATE utf8mb4_unicode_520_ci,
  `file_hash` varchar(128) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_future_file` int(1) DEFAULT '0',
  PRIMARY KEY (`file_id`),
  KEY `file` (`file`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
TRUNCATE TABLE `wp_wptc_processed_restored_files`;

# --------------------------------------------------------

