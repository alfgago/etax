CREATE TABLE IF NOT EXISTS `wp_wptc_inc_exc_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `category` varchar(30) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `action` varchar(30) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `table_structure_only` int(1) DEFAULT NULL,
  `is_dir` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `key` (`key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=194 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
TRUNCATE TABLE `wp_wptc_inc_exc_contents`;
 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('2', '/wp-content/managewp/backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('4', '/wp-content/cc303868adf12f7faef7276cf4a24d5d/iwp_backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('6', '/wp-content/infinitewp', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('8', '/wp-content/e51f790674842adfc64dd712f17a9ac3/mwp_backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('10', '/wp-content/backupwordpress', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('12', '/wp-content/contents/cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('14', '/wp-content/content/cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('16', '/wp-content/cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('18', '/wp-content/logs', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('22', '/wp-content/w3tc', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('24', '/wp-content/cmscommander/backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('26', '/wp-content/gt-cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('28', '/wp-content/wfcache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('30', '/wp-content/widget_cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('32', '/wp-content/bps-backup', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('34', '/wp-content/old-cache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('38', '/wp-content/nfwlog', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('40', '/wp-content/upgrade', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('42', '/wp-content/wflogs', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('44', '/wp-content/tmp', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('46', '/wp-content/backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('50', '/wp-content/wishlist-backup', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('52', '/wp-content/wptouch-data/infinity-cache/', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('54', '/wp-content/mysql.sql', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('56', '/wp-content/DE_clTimeTaken.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('58', '/wp-content/DE_cl.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('60', '/wp-content/DE_clMemoryPeak.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('62', '/wp-content/DE_clMemoryUsage.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('64', '/wp-content/DE_clCalledTime.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('66', '/wp-content/DE_cl_func_mem.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('68', '/wp-content/DE_cl_func.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('70', '/wp-content/DE_cl_server_call_log_wptc.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('72', '/wp-content/DE_cl_dev_log_auto_update.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('74', '/wp-content/DE_cl_dev_log_auto_update.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('76', '/wp-content/wptc-server-request-logs.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('78', '/wp-content/wptc-logs.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('80', '/wp-content/wptc-memory-peak.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('82', '/wp-content/wptc-memory-usage.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('84', '/wp-content/wptc-time-taken.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('86', '/wp-content/wptc-cpu-usage.txt', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('88', '/wp-content/debug.log', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('90', '/wp-content/Dropbox_Backup', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('92', '/wp-content/backup-db', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('94', '/wp-content/updraft', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('96', '/wp-content/w3tc-config', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('98', '/wp-content/aiowps_backups', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('153', '/wp-admin/php_errorlog', 'file', 'backup', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('154', '/wp-admin/php_errorlog', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('155', '/error_log', 'file', 'backup', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('156', '/error_log', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('157', '/error.log', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('158', '/error.log', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('159', '/debug.log', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('160', '/debug.log', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('161', '/WS_FTP.LOG', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('162', '/WS_FTP.LOG', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('163', '/security.log', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('164', '/security.log', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('165', '/wp-tcapsule-bridge.zip', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('166', '/wp-tcapsule-bridge.zip', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('167', '/dbcache', 'file', 'backup', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('168', '/dbcache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('169', '/pgcache', 'file', 'backup', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('170', '/pgcache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('171', '/objectcache', 'file', 'backup', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('172', '/objectcache', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('173', 'wp_redirection_404', 'table', 'backup', 'include', '1', NULL); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('174', 'wp_redirection_404', 'table', 'staging', 'include', '1', NULL); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('175', 'wp_redirection_logs', 'table', 'backup', 'include', '1', NULL); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('176', 'wp_redirection_logs', 'table', 'staging', 'include', '1', NULL); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('178', '/domains', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('180', '/static', 'file', 'staging', 'exclude', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('181', '/403.php', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('182', '/403.php', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('183', '/favicon.gif', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('184', '/favicon.gif', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('185', '/maintenance.htaccess', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('186', '/maintenance.htaccess', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('187', '/readme.25cab03a95ebd14b89c04a7c5023bc95.html', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('188', '/readme.25cab03a95ebd14b89c04a7c5023bc95.html', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('189', '/readme.75f729760c4d65296dd3b6068fdff567.html', 'file', 'backup', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('190', '/readme.75f729760c4d65296dd3b6068fdff567.html', 'file', 'staging', 'exclude', NULL, '0'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('191', '/static', 'file', 'backup', 'include', NULL, '1'); 
INSERT INTO `wp_wptc_inc_exc_contents` (`id`, `key`, `type`, `category`, `action`, `table_structure_only`, `is_dir`) VALUES ('192', '/domains', 'file', 'backup', 'include', NULL, '1');
# --------------------------------------------------------

