CREATE TABLE IF NOT EXISTS `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_terms`;
 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('1', 'Uncategorized', 'uncategorized', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('2', 'Main Nav', 'main-nav', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('3', 'Utah', 'utah', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('4', 'California', 'california', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('5', 'Nevada', 'nevada', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('6', 'Colorado', 'colorado', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('7', 'Idaho', 'idaho', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('8', 'Washington', 'washington', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('9', 'Texas', 'texas', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('10', '#Utah', 'utah', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('11', '#Stone', 'stone', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('14', 'Large', 'large', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('15', 'Modern', 'modern', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('16', 'Wyoming', 'wyoming', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('17', '#Wyoming', 'wyoming', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('18', '#Signature', 'signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('19', 'wilson', 'wilson', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('20', '#Signature #Big-D #remodel #Wyoming', 'signature-big-d-remodel-wyoming', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('21', '#California #Ocean', 'california-ocean', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('22', 'Medium', 'medium', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('23', 'Wood Flooring', 'wood-flooring', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('24', 'Stone', 'stone', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('25', '#steel', 'steel', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('26', '#rustic', 'rustic', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('27', 'Reclaimed Timber', 'reclaimed-timber', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('28', '#reclaimed', 'reclaimed', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('29', '#timber', 'timber', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('30', '#pond', 'pond', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('31', 'Board Form Concrete', 'board-form-concrete', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('32', 'Stone fireplace', 'stone-fireplace', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('33', 'Reclaimed Siding', 'reclaimed-siding', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('34', '#siding', 'siding', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('35', '#log', 'log', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('36', 'Remodel', 'remodel', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('37', 'Restoration', 'restoration', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('38', 'Steel', 'steel', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('39', '#Snake #River #Signature #Jackson #Restoration', 'snake-river-signature-jackson-restoration', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('40', 'Reclaimed Wood Flooring', 'reclaimed-wood-flooring', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('41', 'Water Feature', 'water-feature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('42', '#teton', 'teton', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('43', 'Jackson', 'jackson-hole', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('44', 'Big-D In the News', 'big-d-in-the-news', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('45', 'Park City', 'park-city', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('46', 'Small', 'small', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('47', 'Cabin', 'cabin', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('48', 'Steel Windows', 'steel-windows', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('49', 'Glass Stairways', 'glass-stairways', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('50', 'Window Walls', 'window-walls', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('51', 'Stone Flooring', 'stone-flooring', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('52', 'Rustic', 'rustic', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('53', 'Historic', 'historic', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('54', 'Ranch', 'ranch', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('55', 'Cabin', 'cabin', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('56', '#jackson', 'jackson', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('57', '#simms #fishing #expansion #montana', 'simms-fishing-expansion-montana', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('58', '#elkfest #jackson #antlers #signature', 'elkfest-jackson-antlers-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('59', 'Construction News', 'construction-news', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('60', '#housing #construction #signature', 'housing-construction-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('61', 'Idaho', 'idaho', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('62', '#citywalk #idaho #housing #huntsman #signature', 'citywalk-idaho-housing-huntsman-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('63', '#driggs', 'driggs', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('64', '#ParkCity #Utah #tourism #ski #signature', 'parkcity-utah-tourism-ski-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('65', '#ShootingStar', 'shootingstar', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('66', '#fishcreek', 'fishcreek', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('67', '#corona', 'corona', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('68', '#beaches', 'beaches', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('69', '#amangani', 'amangani', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('70', '#RRR #jackson #big-d #signature', 'rrr-jackson-big-d-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('71', '#byu #idaho #central #energy #cogeneration', 'byu-idaho-central-energy-cogeneration', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('72', '#residential #signature #idaho #huntsmansprings', 'residential-signature-idaho-huntsmansprings', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('73', '#jackson #barBC #signature', 'jackson-barbc-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('74', '#guesthouse #jackson #wyoming #rustic #signature', 'guesthouse-jackson-wyoming-rustic-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('75', '#construction #housing #commerce #report #signature', 'construction-housing-commerce-report-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('76', 'Utah', 'utah', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('77', '#kidsfair #bigd #utah #signature #dr!ve', 'kidsfair-bigd-utah-signature-drve', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('78', '#school #modularconstruction #construction #CLC #signature #jackson', 'school-modularconstruction-construction-clc-signature-jackson', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('79', 'Tennessee', 'tennessee', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('80', '#victory #ranch #cabinhomes #utah #parkcity #signature', 'victory-ranch-cabinhomes-utah-parkcity-signature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('81', 'Feature', 'feature', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('82', '#art #jacksonhole #fall #festival #jackson #wyoming', 'art-jacksonhole-fall-festival-jackson-wyoming', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('83', '#big-d', 'big-d', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('84', '#lehi', 'lehi', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('85', '#chamber', 'chamber', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('86', '#business #award', 'business-award', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('87', '#signature #newwebsite', 'signature-newwebsite', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('88', '#signature #website #bigd #construction', 'signature-website-bigd-construction', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('89', '#shooting #star #cowgirl #magazine #article #home #wyoming', 'shooting-star-cowgirl-magazine-article-home-wyoming', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('90', '#jackson #house #gros #ventre #homeoftheyear', 'jackson-house-gros-ventre-homeoftheyear', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('91', '#modern #magazine #homeoftheyear #jackson', 'modern-magazine-homeoftheyear-jackson', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('92', 'Montana', 'montana', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('93', 'Pennsylvania', 'pennsylvania', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('94', 'Resort', 'resort', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('95', 'Residential', 'residential', '0'); 
INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES ('96', 'Other projects', 'other-projects', '0');
# --------------------------------------------------------

