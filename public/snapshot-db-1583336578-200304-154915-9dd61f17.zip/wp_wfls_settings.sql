CREATE TABLE IF NOT EXISTS `wp_wfls_settings` (
  `name` varchar(191) NOT NULL DEFAULT '',
  `value` longblob,
  `autoload` enum('no','yes') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_wfls_settings`;
 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('allow-xml-rpc', '1', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('captcha-stats', '{"counts":[0,0,0,0,0,0,0,0,0,0,0],"avg":0}', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('delete-deactivation', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('enable-auth-captcha', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('global-notices', '[]', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('ip-source', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('ip-trusted-proxies', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('last-secret-refresh', '1558104439', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('ntp-offset', '0.25282669067383', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('recaptcha-threshold', '0.5', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('remember-device', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('remember-device-duration', '2592000', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('require-2fa-grace-period-enabled', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('require-2fa.administrator', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('shared-hash-secret', '3fef8b53956df155f3ccea50ec207cc52cbb79e36541a1a1294849d58fabb2ba', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('shared-symmetric-secret', '7774bcdf5395b09e525f954fa9c5d8f4bba9c46599fcf58be0497249d96c9855', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('use-ntp', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('whitelisted', '', 'yes'); 
INSERT INTO `wp_wfls_settings` (`name`, `value`, `autoload`) VALUES ('xmlrpc-enabled', '1', 'yes');
# --------------------------------------------------------

