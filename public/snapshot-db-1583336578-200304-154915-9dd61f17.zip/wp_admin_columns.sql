CREATE TABLE IF NOT EXISTS `wp_admin_columns` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `list_key` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `columns` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `settings` mediumtext COLLATE utf8mb4_unicode_520_ci,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `list_id` (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
TRUNCATE TABLE `wp_admin_columns`;
 
INSERT INTO `wp_admin_columns` (`id`, `list_id`, `list_key`, `title`, `columns`, `settings`, `date_created`, `date_modified`) VALUES ('1', '5e5df6076a838', 'project_default', 'Original', 'a:3:{i:0;s:2:"cb";i:1;s:5:"title";i:2;s:4:"date";}', 'a:0:{}', '2020-03-03 06:15:35', '2020-03-03 06:15:35'); 
INSERT INTO `wp_admin_columns` (`id`, `list_id`, `list_key`, `title`, `columns`, `settings`, `date_created`, `date_modified`) VALUES ('2', '5e5df6076a843', 'project', 'Original', 'a:6:{s:5:"title";a:6:{s:11:"column-name";s:5:"title";s:4:"type";s:5:"title";s:5:"clone";s:0:"";s:5:"label";s:5:"Title";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}s:15:"column-taxonomy";a:7:{s:11:"column-name";s:15:"column-taxonomy";s:4:"type";s:15:"column-taxonomy";s:5:"clone";s:0:"";s:5:"label";s:8:"Location";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";s:8:"taxonomy";s:8:"location";}s:17:"column-taxonomy-1";a:7:{s:11:"column-name";s:17:"column-taxonomy-1";s:4:"type";s:15:"column-taxonomy";s:5:"clone";s:1:"1";s:5:"label";s:9:"Materials";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";s:8:"taxonomy";s:8:"material";}s:17:"column-taxonomy-2";a:7:{s:11:"column-name";s:17:"column-taxonomy-2";s:4:"type";s:15:"column-taxonomy";s:5:"clone";s:1:"2";s:5:"label";s:5:"Sizes";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";s:8:"taxonomy";s:4:"size";}s:17:"column-taxonomy-3";a:7:{s:11:"column-name";s:17:"column-taxonomy-3";s:4:"type";s:15:"column-taxonomy";s:5:"clone";s:1:"3";s:5:"label";s:6:"Styles";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";s:8:"taxonomy";s:5:"style";}s:4:"date";a:6:{s:11:"column-name";s:4:"date";s:4:"type";s:4:"date";s:5:"clone";s:0:"";s:5:"label";s:4:"Date";s:5:"width";s:0:"";s:10:"width_unit";s:1:"%";}}', 'a:0:{}', '2020-03-03 06:15:35', '2020-03-03 06:15:35');
# --------------------------------------------------------

